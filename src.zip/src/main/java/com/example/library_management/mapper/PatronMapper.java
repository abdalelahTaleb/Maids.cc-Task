package com.example.library_management.mapper;

import com.example.library_management.dto.PatronDTO;
import com.example.library_management.entity.Patron;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel = "spring")
public interface PatronMapper {

    PatronDTO toDTO(Patron patron);
    Patron toEntity(PatronDTO patronDTO);
}
